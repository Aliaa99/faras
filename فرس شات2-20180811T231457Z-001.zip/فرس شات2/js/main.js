$(function(){
    'use strict';

    $('.button-collapse').sideNav({
      menuWidth : 300,
      draggable: true,
      edge:'right'
    });
    // Hide sideNav
    $('.exit-sidenav').click(function() {
        $(this).sideNav('hide');
    }); 

        //owl carousel

    $('.owl-carousel').owlCarousel({
      stagePadding: 25,
      dots:false,
      rtl:true,
      autoplay:false,
      loop:true,
      margin:10,
      responsive:{
          0:{
              items:4
          },
          600:{
              items:5
          },
          1000:{
              items:5
          }
        }
    });
    
                // popup 1
    
    $('.box').click(function(){
        $('.overlay').css({"opacity":"1","visibility":"visible"});
        $(this).clone().appendTo('.as');
        
    });
    $(".close").click(function(){
        $('.overlay,.overlay2 ,.overlay3').css({"opacity":"0","visibility":"hidden"});
        $('.as , .as2').empty();
    });
    
                //popup chat
    $('.owl-carousel .item img ,.popside ,.messbutt').click(function(){
        $('.overlay2').css({"opacity":"1","visibility":"visible"});
        $(this).clone().appendTo('.as2');
    });


    $('.sendpop').click(function(){
        $('.overlay3').css({"opacity":"1","visibility":"visible","z-index": "2"});
    });

    $(".nicescroll-box ,.nicescroll-box2").niceScroll(".wrap",{cursorcolor:"#13a5e0",cursorwidth:"5px",background:"rgba(193,192,192,0.5)",cursorborder:"1px solid #afafaf",autohidemode:'leave'});



});